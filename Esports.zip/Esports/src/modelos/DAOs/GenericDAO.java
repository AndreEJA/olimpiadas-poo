package modelos.DAOs;

import java.util.ArrayList;

public abstract class GenericDAO<T> {
    protected ArrayList<T> data = new ArrayList<>();

    public void Add(T item) {
        data.add(item);
    }

    public void Remove(T item) {
        data.remove(item);
    }
}
