package modelos.DAOs;

import modelos.Torneo;

public class TorneoDAO extends GenericDAO<Torneo> {
    public Torneo EncontrarPorID(int id) {
        for(Torneo torneo : data) {
            if(torneo.getId() == id)
                return torneo;
        }
        return null;
    }

    public void ImprimirTorneos() {
        for(int i = 0; i < data.size(); i++)
            System.out.println("#" + (i + 1) + ". " + data.get(i).toString());
    }
}
