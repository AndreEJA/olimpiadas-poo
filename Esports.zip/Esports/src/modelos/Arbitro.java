package modelos;

public class Arbitro extends Persona {
    public Arbitro(String id, String nombre) {
        super(id, nombre);
    }
}
